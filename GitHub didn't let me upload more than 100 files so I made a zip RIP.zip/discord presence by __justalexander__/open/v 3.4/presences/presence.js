
console.log("----------------------------------------------------------");
console.log("Packet made by __justalexander__ . Powered by discord rcp.");
console.log(" ---------------------------------------------------------");


module.exports = {
    name: 'presence',
    async execute(client) {
        client.setActivity({
            largeImageKey: 'LargeImageClientKey',
            largeImageText: 'Large image hover text',
            details: "Upper text",
            state: "Bottom text",
            buttons: [
                { label: "Button1", url: "https://yoururl.yourur" },
                { label: "Button2", url: "https://yoururl.yoururl" },
            ],
            instance: false,
        });
    }
}

console.log(" STATUS CHECK: ONLINE If you see this message, means your status is still online!");
